from pyrep.robots.arms.arm import Arm


class Harvey(Arm):

    def __init__(self, count: int = 0):
        super().__init__(count, 'Harvey', num_joints=7)

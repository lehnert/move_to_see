#!/bin/bash

# assumes wsl ubuntu 20.04 fresh install
# MTS3D_Setup.sh, pyrep_setup.sh, and harvey.py in desired installation directory
# source pyrep.sh before starting (having edited it appropriately)

# general background updates
set -e # exit when any command fails

# misc libraries
sudo apt install liblua5.1-0-dev -y
sudo apt-get install qt5-default -y
sudo apt-get install libavcodec-dev libavformat-dev libswscale-dev -y

# python libraries
sudo apt install python3-pip -y # remove this if pip is installed
pip3 install scikit-learn matplotlib pygame opencv-python==4.3.0.36 # version avoids xcb-plugin error
pip3 install roboticstoolbox-python
sudo apt install python3.8-tk # for displaying plots
# coppeliasim
wget https://www.coppeliarobotics.com/files/CoppeliaSim_Edu_V4_1_0_Ubuntu20_04.tar.xz
tar -xf CoppeliaSim_Edu_V4_1_0_Ubuntu20_04.tar.xz

# run headless
sudo apt-get install xvfb -y # remove this if xvfb is already installed

# git repos
sudo apt install git -y # remove this if git is already installed

git clone https://github.com/lehnert/move_to_see.git

git clone https://github.com/stepjam/PyRep.git
cp harvey.py ./PyRep/pyrep/robots/arms
cd PyRep
pip3 install -r requirements.txt
pip3 install .
cd ..